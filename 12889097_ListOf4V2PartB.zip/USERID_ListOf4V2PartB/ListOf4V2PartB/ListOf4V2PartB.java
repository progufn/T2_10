/**
 * This class maintains a list of 4 integers.
 * 
 * This list is simple and unusual in it always contains exactly the
 * same number of elements.  Later, when we know more Java, we will
 * study classes where the number of elements may vary. 
 * 
 * In this version 2, we use variables in the subscripts.
 * 
 * @author Raymond Lister 
 * @version August 2014
 * 
 */
public class ListOf4V2PartB
{
    private static final int listSize = 4;
    
    private int[] list = {0, 1, 2, 3};

    
    /**
     * A constructor for objects of class ListOf4, which takes a
     * single array parameter
     * 
     * @param  element   the initial elements for the list
     */
    public returnTypeIfAny nameOfConstructor(int [] element)
    {   
      // with variable subscripts ... 
      int i = first position in the array; // role: stepper
      list[subscript1] = element[subscript2];
      i = new value;
      copy and paste some of the code above, as many times as required
      
    } // constructor ListOf4(int [] element)
    
    /**
     * @return     the first element in the list
     */
    public returntype getFirst(parametersIfAny)
    {
        return something;  
        
    } // method getFirst      
    
     
    /**
     * @return     A summary of the contents of the list.
     */
    public returntype toString(parametersIfAny)
    {
       // with variable subscripts ... 
       String s = "{" + list[0]; // role: gatherer
       int i = initial value;      // role: stepper
       
       s = s + ", " + list[sub];
       i = nextValueForI;
       copy and paste some of the code above, as many times as required
              
       s = s + "}";
       
       return theString;
    }
    
    /**
     * @return     the sum of the elements of the array
     */
    public returntype sum(parametersIfAny)
    {
       int sum = 0; // role: gatherer
        
       // with variable subscripts ... 
       int i = beginning value; // role: stepper
 
       sum = sum + list[aSubscript];
       i = iNextValue;
       copy and paste some of the code above, as many times as required

       return theAnswer;
        
    } // method sum 
    
    /**
     * @return     the number of times the replacement was made (i.e. 0 or 1)
     * 
     * @param  replaceThis   the element to be replaced
     * @param  withThis      the replacement
     */
    public returntype replaceOnce(parametersIfAny)
    {        
        // with variable subscripts ... 
        int i = beginning value; // role: stepper
 
        if ( list[sub] == thing )
        {
           list[sub] = something;
           return something;
        }

        increment something;
       
        copy and paste some of the code above, as many times as required 
 
        return somethingElse;
            
    } // method replaceOnce 
          
    
    /**
     * @return     the value of the smallest element in the array
     */
    public returntype minVal(parametersIfAny)
    {
        int mostWantedHolder = initial value;  // role: Most-wanted holder 
        // variable mostWantedHolder remembers the smallest value so far
        
        // with variable subscripts ... 
        int i = initial value; // role: stepper
 
        if ( subscript1] < list[subscript2] )
        {
           update mostWantedHolder
        }
 
       i = newVal;
 
       copy and paste some of the code above, as many times as required
 
       return theAppropriateValue;
        
    } // method minVal
           
    /**
     * Inserts an element in the first position. The elements already in the
     * list are pushed up one place, and the element that was previously
     * last is lost from the list.
     * 
     * @param  newElement   the element to be inserted
     */
    public returntype insertFirst(parametersIfAny)
    {   
        // with variable subscripts ... 
        int i = initial value; // role: stepper
        list[subscript1] = list[subscript2];
        i = newVal;
        copy and paste some of the code above, as many times as required
        
        list[subscript3] = newElement;
        
    } // method insertFirst
     
       
    /**
     *  Swaps two elements in the list
     *  
     * @param  i   the position of one of the elements to be swapped
     * @param  j   the position of one of the elements to be swapped
     */
    public void swap(int i, int j)
    {
        int temp; // role: temporary
        
           temp = list[i];
        list[i] = list[j];
        list[j] = temp;
        
    } // method swap
       
    
    /**
     * "So the first shall be last, and the last first"
     *  -- The Christian Bible, book of Matthew 20:16
     */
    public returntype reverse(parametersIfAny)
    {   
       // with variable subscripts ...
       int i = initial value; // role: stepper
       int j = initial value; // role: stepper
       swap(i, j);
       i = newVal;
       j = newVal;
       swap(i, j);
        
    } // method reverse
 
    /**
     * Orders the elements of the list, with the first element smallest and the
     * last element largest.   Does this using the selection sort algorithm.
     */
    public returntype sortSelection(parametersIfAny)
    {
       /* This implementation uses the selection sort algorithm. For an
        * explanation of how bubblesort works, google ...
        *            selection sort java
        */
       
       int mostWantedHolder;
       
       // with variable subscripts ...
       int i;        // role: stepper

       mostWantedHolder = initialize;
       i = mostWantedHolder + 1;
       if ( list[subscript1] < list[subscript2] ) mostWantedHolder = something;
       i = nextVal;
       copy and paste some of the code above, as many times as required
       swap(pos1, pos2); // smallest now in position 0
        
       update mostWantedHolder
       i = mostWantedHolder + 1;
       copy and paste some of the code above, as many times as required
       swap(pos1, pos2); // second smallest in position 1
            
       update mostWantedHolder
       i = mostWantedHolder + 1;
       copy and paste some of the code above, as many times as required
       swap(pos1, pos2); // second smallest in position 1
       
    } // method sortSelection
   
} // class ListOf4Version2